package TestArtifacts.Test9;

public class TestClass9_02 {


    public int member_variable=10;

    public int getSomeValue() {
        return 100;
    }
}
