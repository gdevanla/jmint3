package TestArtifacts.Test9;

/*
   Test case when local variable in one class
   is used in external class
 */
public class TestIntg9
{
    public static void main(String[] args){
        TestClass9_01 t = new TestClass9_01();
        t.F1();
    }
}
