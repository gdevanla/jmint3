package TestArtifacts.Test3;

public class TestClass3_01 {

    public int x = 10;

    public void F1(){
        TestClass3_02 t1_02 = new TestClass3_02();
        t1_02.useMemberInstance();
    }
}


