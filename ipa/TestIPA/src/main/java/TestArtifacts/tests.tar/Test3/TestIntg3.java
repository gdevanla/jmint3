package TestArtifacts.Test3;

/*
   Test case when local variable in one class
   is used in external class
 */
public class TestIntg3
{

    public static void main(String[] args){
        TestClass3_01 t = new TestClass3_01();
        t.F1();
    }
}
