package TestArtifacts.Test6;

public class TestClass6_02 {

    public int getSomeValue() {
        return 100;
    }
}
