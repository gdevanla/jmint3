package TestArtifacts.Test10;

public class TestClass10_02 {


    public int member_variable=10;

    public int getSomeValue() {
        return 100;
    }
}
