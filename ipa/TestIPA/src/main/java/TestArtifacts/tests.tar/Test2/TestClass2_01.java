package TestArtifacts.Test2;

public class TestClass2_01 {

    int x = 10;

    public void F1(){
        TestClass2_02 t1_02 = new TestClass2_02();
        t1_02.useLocalVariable(x);
    }
}


