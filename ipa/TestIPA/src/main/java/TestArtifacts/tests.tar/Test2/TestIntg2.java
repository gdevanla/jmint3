package TestArtifacts.Test2;

/*
   Test case when local variable in one class
   is used in external class
 */
public class TestIntg2 {

    public static void main(String[] args){
        TestClass2_01 t = new TestClass2_01();
        t.F1();
    }
}
