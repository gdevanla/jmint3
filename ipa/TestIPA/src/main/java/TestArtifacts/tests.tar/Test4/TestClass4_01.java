package TestArtifacts.Test4;

public class TestClass4_01 {

    public int x = 10;

    public void F1(){
        TestClass4_02 t1_02 = new TestClass4_02();
        t1_02.useMemberInstance();
    }
}


