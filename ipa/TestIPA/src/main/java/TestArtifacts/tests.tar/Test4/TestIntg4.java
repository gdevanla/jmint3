package TestArtifacts.Test4;

/*
   Test case when local variable in one class
   is used in external class
 */
public class TestIntg4
{
    public static void main(String[] args){
        TestClass4_02 t = new TestClass4_02();
        t.useMemberInstance();
    }
}
