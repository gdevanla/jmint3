package TestArtifacts.Test7;

/*
   Test case when local variable in one class
   is used in external class
 */
public class TestIntg7
{
    public static void main(String[] args){
        TestClass7_01 t = new TestClass7_01();
        t.F1();
    }
}
