package TestArtifacts.Test7;

public class TestClass7_02 {

    public int getSomeValue() {
        return 100;
    }

    public void updateObject(TestClass7_03 t7_03) {
        t7_03.x = 10;
    }
}
