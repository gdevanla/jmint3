package TestArtifacts.Test7;

public class TestClass7_03 {
    public int x;
}
