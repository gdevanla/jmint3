package TestArtifacts.Test8;

public class TestClass8_03 {
    public int x;
}
