package TestArtifacts.Test8;

public class TestClass8_02 {

    public int getSomeValue() {
        return 100;
    }

    public void updateObject(TestClass8_03 t7_03) {
        t7_03.x = 10;
    }
}
