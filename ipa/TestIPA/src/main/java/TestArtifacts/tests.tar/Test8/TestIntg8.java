package TestArtifacts.Test8;

/*
   Test case when local variable in one class
   is used in external class
 */
public class TestIntg8
{
    public static void main(String[] args){
        TestClass8_01 t = new TestClass8_01();
        t.F1();
    }
}
