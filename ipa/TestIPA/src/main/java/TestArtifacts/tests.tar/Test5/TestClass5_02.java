package TestArtifacts.Test5;

public class TestClass5_02 {

    public int getSomeValue() {
        return 100;
    }
}
