package TestArtifacts.Test5;

/*
   Test case when local variable in one class
   is used in external class
 */
public class TestIntg5
{
    public static void main(String[] args){
        TestClass5_01 t = new TestClass5_01();
        t.F1();
    }
}
