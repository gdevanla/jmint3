package TestArtifacts.Test1;

import TestArtifacts.Test2.TestClass2_02;

public class TestClass1_01 {
    public void F1(){
        int x = 100;
        TestClass1_02 t1_02 = new TestClass1_02();
        t1_02.useLocalVariable(x);
    }
}


